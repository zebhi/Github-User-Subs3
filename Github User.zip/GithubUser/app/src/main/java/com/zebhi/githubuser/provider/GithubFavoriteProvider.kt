package com.zebhi.githubuser.provider

import android.content.ContentProvider
import android.content.ContentUris
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.net.Uri
import com.zebhi.githubuser.BuildConfig
import com.zebhi.githubuser.model.User
import com.zebhi.githubuser.room.UsersDAO
import com.zebhi.githubuser.room.UsersDatabase
import com.zebhi.githubuser.room.table.UsersEntity

class GithubFavoriteProvider : ContentProvider() {

    private lateinit var users: User
    private lateinit var usersDAO: UsersDAO

    companion object {
        const val AUTHORITY = "com.zebhi.githubuser"

        private const val CODE_USERS_DIR = 1
        private const val CODE_USERS_ITEM = 2
        private val MATCHER: UriMatcher = UriMatcher(UriMatcher.NO_MATCH)
    }

    init {
        MATCHER.addURI(AUTHORITY, "users_table", CODE_USERS_DIR)
        MATCHER.addURI(AUTHORITY, "users_table/#", CODE_USERS_ITEM)
    }

    override fun insert(uri: Uri, contentValues: ContentValues?): Uri? {
        return when (MATCHER.match(uri)) {
            CODE_USERS_DIR -> {
                val context = context ?: return null
                if (BuildConfig.DEBUG && contentValues == null) {
                    error("Assertion failed")
                }
                val id: Long = UsersDatabase.getInstance(context)?.usersDao()!!
                    .insertUserFavorite(UsersEntity.entity(users))
                context.contentResolver.notifyChange(uri, null)
                ContentUris.withAppendedId(uri, id)
            }
            CODE_USERS_ITEM -> throw IllegalArgumentException("Invalid URI, cannot insert with ID: $uri")
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
    }

    override fun query(
        uri: Uri,
        projection: Array<String>?,
        selection: String?,
        selectionArgs: Array<String>?,
        sortOrder: String?
    ): Cursor? {
        val cursor: Cursor
        val context = context

        return if (context != null) {
            when (MATCHER.match(uri)) {
                CODE_USERS_DIR -> {
                    cursor = usersDAO.getUsersProvider()
                    cursor.setNotificationUri(context.contentResolver, uri)
                    cursor
                }
                CODE_USERS_ITEM -> throw IllegalArgumentException("Invalid URI: $uri")
                else -> throw IllegalArgumentException("Unknown URI: $uri")
            }
        } else {
            null
        }
    }

    override fun onCreate(): Boolean {
        usersDAO = context?.let { UsersDatabase.getInstance(it)?.usersDao() }!!

        return true
    }

    override fun update(
        uri: Uri,
        contentValues: ContentValues?,
        selection: String?,
        selectionArgs: Array<String>?
    ): Int {
        return 0
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        return when (MATCHER.match(uri)) {
            CODE_USERS_DIR -> throw IllegalArgumentException("Invalid URI, cannot delete without ID $uri")
            CODE_USERS_ITEM -> {
                val context = context ?: return 0
                val count: Int = UsersDatabase.getInstance(context)?.usersDao()!!
                    .deleteUser(null)
                context.contentResolver.notifyChange(uri, null)
                count
            }
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
    }

    override fun getType(p0: Uri): String? {
        return null
    }
}
