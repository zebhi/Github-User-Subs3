package com.zebhi.githubuser

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.zebhi.githubuser.adapter.SectionsPagerAdapter
import com.zebhi.githubuser.databinding.ActivityUserDetailBinding
import com.zebhi.githubuser.model.User
import com.zebhi.githubuser.room.UsersDAO
import com.zebhi.githubuser.room.UsersDatabase
import com.zebhi.githubuser.room.table.UsersEntity

class ActivityUserDetail : AppCompatActivity() {

    private lateinit var binding: ActivityUserDetailBinding
    private lateinit var usersDao: UsersDAO
    private lateinit var users: User

    companion object {
        const val EXTRA_USERS = "extra_users"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserDetailBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        usersDao = UsersDatabase.getInstance(this)?.usersDao()!!

        users = intent.getParcelableExtra(EXTRA_USERS)!!

        binding.tvDetailUsername.text = users.login.toString()
        binding.tvDetailHtmlUrl.text = users.html_url.toString()

        val avatarUrl: String = users.avatar_url.toString()

        Glide.with(this)
            .load(avatarUrl)
            .centerCrop()
            .into(binding.ivDetailAvatar)

        val username = users.login.toString()

        binding.viewPager.adapter = SectionsPagerAdapter(supportFragmentManager, this, username)
        binding.tabs.setupWithViewPager(binding.viewPager, true)

        refreshFavorite()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.options_menu, menu)

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_favorite -> {
                val intentFavorites = Intent(this, FavoriteActivity::class.java)
                startActivity(intentFavorites)
                true
            }
            R.id.menu_setting -> {
                val intentSettings = Intent(this, SettingsActivity::class.java)
                startActivity(intentSettings)
                true
            }
            else -> true
        }
    }

    fun favoriteClick(view: View) {
        if (view.id == R.id.add_to_favorite) {
            if (!isFavorite) {
                usersDao.insertUserFavorite(UsersEntity.entity(users))
            } else {
                usersDao.deleteUser(users.id)
            }
            refreshFavorite()
        }
    }

    private var isFavorite: Boolean = false

    private fun refreshFavorite() {
        isFavorite = if (usersDao.getUser(users.id) != null) {
            binding.addToFavorite.setImageResource(R.drawable.ic_favorite_full)
            true
        } else {
            binding.addToFavorite.setImageResource(R.drawable.ic_favorite_border)
            false
        }
    }
}
